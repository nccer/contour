#ifndef SDF_H
#define SDF_H

#include <QObject>

class Sdf : public QObject
{
    Q_OBJECT
public:
    explicit Sdf(QObject *parent = 0);
    Q_INVOKABLE void generateSDF(QString str1, QString str2, QString str3, QString str4);

signals:

public slots:
};

#endif // SDF_H
