#include "sdf.h"
#include <QDebug>
#include <QFile>
#include <QList>

Sdf::Sdf(QObject *parent) : QObject(parent)
{

}
void Sdf::generateSDF(QString str1, QString str2, QString str3, QString str4) {
    QString casRegistryNumber("CAS Registry Number");
    QFile sdf(str1);
    QFile csv(str2);
    QFile result(str4 + "/result.sdf");
    QList<QString> casList;
    QList<QString> missingcasList;

    if(sdf.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream sdfStream(&sdf);
        QString sdfLine = sdfStream.readLine();
        if(result.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
            QTextStream resultStream(&result);
            while(!sdfLine.isNull()) {
                resultStream<<sdfLine<<"\n";
                if(!QString::compare(sdfLine, casRegistryNumber)) {
                    sdfLine = sdfStream.readLine();
                    casList<<sdfLine;
                } else {
                    sdfLine = sdfStream.readLine();
                }
            }
        }
    }
    sdf.close();
    result.close();
    if(csv.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream csvStream(&csv);
        QString csvLine = csvStream.readLine();
        QStringList titleList = csvLine.split(",");
        int casLocate = 0;
        bool isFindCAS = false;
        foreach(QString va_arg, titleList) {
            if(!QString::compare(casRegistryNumber, va_arg)) {
                casLocate = titleList.indexOf(va_arg);
                isFindCAS = true;
                qDebug()<<casLocate;
            }
        }
        csvLine = csvStream.readLine();
        if(isFindCAS) {
            while(!csvLine.isNull()) {
                QStringList varList = csvLine.split(",");
                if(casList.indexOf(varList.at(casLocate)) == -1) {
                    qDebug()<<"find "<<varList.at(casLocate)<<"\n";
                    continue;
                }
                QString molFileName(str3 + "/" + varList.at(casLocate) + ".mol");
                QFile mol(molFileName);
                if(mol.open(QIODevice::ReadOnly | QIODevice::Text)) {
                    QTextStream molStream(&mol);
                    QString molLine = molStream.readLine();
                    if(result.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
                        QTextStream resultStream(&result);
                        while(!molLine.isNull()) {
                            resultStream<<molLine<<"\n";
                            molLine = molStream.readLine();
                        }
                        foreach (QString va_arg, titleList) {
                            QString titleString(">   <" + va_arg + ">\n");
                            QString valueString(varList.at(titleList.indexOf(va_arg)) + "\n");
                            resultStream<<titleString;
                            resultStream<<valueString;
                        }
                        resultStream<<"$$$$\n";
                        result.close();
                    }
                } else {
                    missingcasList<<varList.at(casLocate)<<"\n";
                }
                csvLine = csvStream.readLine();
            }
        }
    }
    foreach (QString casNumber, missingcasList) {
        QFile missingcas(str4 + "failed.txt");
        if(missingcas.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
            QTextStream missingcasStream(&missingcas);
            missingcasStream<<casNumber<<"\n";
        }
    }
}
